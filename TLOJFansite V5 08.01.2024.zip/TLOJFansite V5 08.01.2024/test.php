<p>TLOJFansite.test.php</p>

<!-- slider -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/bxslider/4.2.12/jquery.bxslider.css">
<script "text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script "text/javascript" src="https://cdn.jsdelivr.net/bxslider/4.2.12/jquery.bxslider.min.js"></script>

<div class="slider">
    <h3>Slide One</h3>
    <h3>Slide Two</h3>
    <h3>Slide Three</h3>
</div>

<script>
    $(document).ready(function(){
        $('.slider').bxSlider();
    });
</script>

<!-- append database -->
<form action="signup-php.php" method="POST">
    <label for="username">Username:</label><br>
    <input type="text" id="username" name="username" value=""><br>
    <label for="password">Password:</label><br>
    <input type="password" id="password" name="password" value=""><br>
    <label for="email">Email:</label><br>
    <input type="text" id="email" name="email" value=""><br><br>
  <!-- submit details -->
  <input type="submit" value="Create">
</form>

<!-- <?php

    echo $servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "eternalsfansite";

	$uname = $_POST["username"];
	$pword = $_POST["password"];
	$email = $_POST["email"];

	echo $uname;
	echo $pword;
	echo $email;

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
	  die("Connection failed: " . $conn->connect_error);
	}

	$sql = "INSERT INTO users (username,password,email)
	VALUES (?,?,?)";

	$stmt = $conn->prepare("INSERT INTO users (username,password,email)
	VALUES (?,?,?)");
	$stmt->bind_param("sss",$uname ,$pword, $email);
	$stmt->execute();
	$conn->close();
    
?> -->
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <!-- <meta http-equiv="Content-Security-Policy" content="default-src 'self'; img-src https://*; child-src 'none';" /> -->
        <title>The Highs and Lows of Being a Superhero Fansite</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Bootstrap Icons-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Merriweather+Sans:400,700" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic" rel="stylesheet" type="text/css" />
        <!-- SimpleLightbox plugin CSS-->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/SimpleLightbox/2.1.0/simpleLightbox.min.css" rel="stylesheet" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body id="page-top">
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-dark fixed-top py-3" id="mainNav">
            <div class="container px-4 px-lg-5">
                <a class="navbar-brand" href="#page-top">The Highs and Lows of Being a Superhero Fansite</a>
            </div>
        </nav>
        <!-- Masthead-->
        <header class="masthead">
            <div class="container px-4 px-lg-5 h-100">
                <div class="row gx-4 gx-lg-5 h-100 align-items-center justify-content-center text-center">
                    <div class="col-lg-8 align-self-end">
                        <h1 class="text-white font-weight-bold"> The Highs and Lows of Being a Superhero </h1>
                        <hr class="divider" />
                    </div>
                    <div class="col-lg-8 align-self-baseline">
                        <p class="text-white-75 mb-5">The Legion of Justice are a team of superheroes who use their powers to protect Metcalfe from danger</p>
                        <a class="btn btn-primary btn-xl" href="#about">Find Out More</a>
                    </div>
                </div>
            </div>
        </header>
        <!-- About-->
        <!-- <section class="page-section bg-primary" id="about">
            <div class="container px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-lg-8 text-center">
                        <h2 class="text-white mt-0">We've got what you need!</h2>
                        <hr class="divider divider-light" />
                        <p class="text-white-75 mb-4">Start Bootstrap has everything you need to get your new website up and running in no time! Choose one of our open source, free to download, and easy to use themes! No strings attached!</p>
                        <a class="btn btn-light btn-xl" href="#services">Get Started!</a>
                    </div>
                </div>
            </div>
        </section> -->
        
        <!-- Contact-->
        <section class="page-section" id="contact">
            <div class="container px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-lg-8 col-xl-6 text-center">
                        <h2 class="mt-0">Create an Account</h2>
                        <hr class="divider" />
                        <p class="text-muted mb-5">Create an account to meet Metcalfe's resident Superheroes</p>
                    </div>
                </div>

                <!-- login form -->

                <form action="signup-php.php" method="POST">
                    <label for="username">Username:</label><br>
                    <input type="text" id="username" name="username" value=""><br>
                    <label for="password">Password:</label><br>
                    <input type="password" id="password" name="password" value=""><br>
                    <label for="email">Email:</label><br>
                    <input type="text" id="email" name="email" value=""><br><br>
                  <!-- submit details -->
                  <input type="submit" value="Create">
                </form>

                <!-- <?php
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "eternalsfansite";

                $uname = $_POST["username"];
                $pword = $_POST["password"];
                $email = $_POST["email"];

                echo $uname;
                echo $pword;
                echo $email;

                // Create connection
                $conn = new mysqli($servername, $username, $password, $dbname);
                // Check connection
                if ($conn->connect_error) {
                  die("Connection failed: " . $conn->connect_error);
                }

                $sql = "INSERT INTO users (username,password,email)
                VALUES (?,?,?)";

                $stmt = $conn->prepare("INSERT INTO users (username,password,email)
                VALUES (?,?,?)");
                $stmt->bind_param("sss",$uname ,$pword, $email);
                $stmt->execute();
                $conn->close();
                ?> -->
            </section>
        <!-- Call to action-->
        <section class="page-section bg-dark text-white">
            <div class="container px-4 px-lg-5 text-center">
                <p class="mb-4"> the Legion of Justice are a team of original characters created in 2018 by Nicholas Beard featured in The Highs and Lows of Being a Superhero. Originally consisting of 6 members, the team has grown and evolved over time to be a bit more diverse. </p>
            </div>
        </section>
        <!-- Footer-->
        <footer class="bg-light py-5">
            <div class="container px-4 px-lg-5"><div class="small text-center text-muted">Copyright &copy; The Highs and Lows of Being a Superhero 2023</div></div>
        </footer>
    </body>
</html>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <!-- <meta http-equiv="Content-Security-Policy" content="default-src 'self'; img-src https://*; child-src 'none';" /> -->
        <title>The Highs and Lows of Being a Superhero</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Bootstrap Icons-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Merriweather+Sans:400,700" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic" rel="stylesheet" type="text/css" />
        <!-- SimpleLightbox plugin CSS-->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/SimpleLightbox/2.1.0/simpleLightbox.min.css" rel="stylesheet" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body id="page-top">
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-dark fixed-top py-3" id="mainNav">
            <div class="container px-4 px-lg-5">
                <a class="navbar-brand" href="#page-top">Home</a>
                <button class="navbar-toggler navbar-toggler-right" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ms-auto my-2 my-lg-0">
                        <li class="nav-item"><a class="nav-link" href="home.php">Characters</a></li>
                    </ul>
                </div> 
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ms-auto my-2 my-lg-0">
                        <li class="nav-item"><a class="nav-link" href="table.php">Powers</a></li>
                    </ul>
                </div> 
            </div>
        </nav>
        <!-- Masthead-->
        <header class="masthead">
            <div class="container px-4 px-lg-5 h-100">
                <div class="row gx-4 gx-lg-5 h-100 align-items-center justify-content-center text-center">
                    <div class="col-lg-8 align-self-end">
                        <h1 class="text-white font-weight-bold"> The Highs and Lows of Being a Superhero </h1>
                        <hr class="divider" />
                    </div>
                    <div class="col-lg-8 align-self-baseline">
                        <p class="text-white-75 mb-5">The Legion of Justice are a team of OC superheroes who use their powers to protect Metcalfe from danger. Through their adventures, the Legion members will make allies, enemies and discoveries about their respective pasts and their very powers. </p>
                        <a class="btn btn-primary btn-xl" href="#about">Find Out More</a>
                    </div>
                </div>
            </div>
        </header> 

<section class="page-section cta">
            <div class="container">
                <div class="row">
                    <div class="col-xl-9 mx-auto">
                        <div class="cta-inner bg-faded text-center rounded">
                            <h2 class="section-heading mb-5">
                                <span class="section-heading-upper">Upload a photo </span>
                                <!-- <span class="section-heading-lower">Rate My Cake</span> -->
                            </h2>
    
                            <div style="display: inline-block; text-align: center;">
                            <form action="post.php" method="post" enctype="multipart/form-data">
                            <img id="blah" class="img-thumbnail rounded" style="background-color: #d2984f; max-width: 100%;" src="#" hidden>
                              <br>
                              <br>
                            <input style="width:100%;" id="userImg" type="file" name="image" />
                              <br>
                              
                              <br>
                              <input type="hidden" name="auth" value="upload"/> 
                              <textarea name="review" rows="10" cols="50" placeholder="Enter the review..." required maxlength="255"></textarea>
                              <br>
                              <br>
                              <textarea name="caption" rows="10" cols="50" placeholder="Enter your caption..." required maxlength="255"></textarea>
                              <br>
                              <br>
                              <input style="width:100%;" type="submit" value="Upload" />
                              <input type="hidden" id="width" name="width" value=" 0">
                            		<input type="hidden" id="time" name="time" value=" 0">
                            		<input type="hidden" id="height" name="height" value=" 0">
                            	  <input type="hidden" name="userid" placeholder="Enter your email..."><br>
                            		
                                <input type="hidden" name="password" placeholder="Enter your password"><br>
                            <!-- This is the Image preview window -->

                            </form>
                            </div>
                            <?php  
                              if ((isset($_SESSION["error"])) && ($_SESSION["error"])){
                                echo $_SESSION["error"];
                                $_SESSION["error"] = "";


                              } 
                            ?>

                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php
         $servername = "localhost";
         $username = "root";
         $password = "";
         $dbName = "eternalsfansite";
     
         // Create connection
         $conn = new mysqli($servername, $username, $password, $dbName);
         if ($conn->connect_error) {;
                 die();
         }
         $stmt = $conn->prepare("SELECT * FROM imgupload");
         
        // ORDER BY review_id DESC

        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $imageId = $row["id"];
                $file = $row["image"];
                $file = "uploads/".$file;
                $captions = $row["caption"];

                $array = array("img", "review", "likes", "captions");
            
            echo "
            <section class='page-section cta'>
                <div class='container'>
                    <div class='row'>
                        <div class='col-xl-9 mx-auto'>
                            <div class='cta-inner bg-faded text-center rounded'>
                                <div style='display: inline-block; text-align: center;'>
                                    <img class='img-thumbnail rounded' style='background-color: #d2984f; max-width: 100%; height:100%;' src='" . $file . "'>
                                    <h1>" . $captions . "</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            ";
          
                 
        }
    } else {
        $status = "loggedOut";
        $_SESSION['error'] = "Error: these details are incorrect. Please try again.";
        $_SESSION["status"] = $status;
        // header("location:index.php");
		$conn->close();
    }
        ?>
    
        <!-- Footer-->
        <footer class="bg-light py-5">
            <div class="container px-4 px-lg-5"><div class="small text-center text-muted">Copyright &copy; The Highs and Lows of Being a Superhero 2023</div></div>
        </footer>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
    <script>
             userImg.onchange = evt => {
                            const [file] = userImg.files
                            if (file) {
                                blah.src = URL.createObjectURL(file)
                                blah.hidden = false
                            }
                            }

    function validateTime() {
  var selectedTime = document.getElementById('timepicker').value;
  var parts = selectedTime.split(':');
  var hours = parseInt(parts[0]);
  var minutes = parseInt(parts[1]);

  // Restrict to 9 am to 5:30 pm
  if (hours < 9 || (hours === 17 && minutes > 30) || hours > 17) {
    alert('Please select a time between 9:00 am and 5:30 pm.');
    document.getElementById('timepicker').value = ''; // Clear the input
    return false;
  } else {
    return true;
  }
}


    </script>
    </body>
</html>
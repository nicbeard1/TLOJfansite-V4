<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eternalsfansite";

$uname = $_POST["username"];
$pword = $_POST["password"];
$email = $_POST["email"];

echo $uname;
echo $pword;
echo $email;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO users (username,password,email)
VALUES (?,?,?)";

$stmt = $conn->prepare("INSERT INTO users (username,password,email)
VALUES (?,?,?)");
$stmt->bind_param("sss",$uname ,$pword, $email);
$stmt->execute();
$conn->close();
?>

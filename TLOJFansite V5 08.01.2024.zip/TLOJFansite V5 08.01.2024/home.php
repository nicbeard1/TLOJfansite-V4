<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <!-- <meta http-equiv="Content-Security-Policy" content="default-src 'self'; img-src https://*; child-src 'none';" /> -->
        <title>The Highs and Lows of Being a Superhero Fansite</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Bootstrap Icons-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Merriweather+Sans:400,700" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic" rel="stylesheet" type="text/css" />
        <!-- SimpleLightbox plugin CSS-->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/SimpleLightbox/2.1.0/simpleLightbox.min.css" rel="stylesheet" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body id="page-top">
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-light fixed-top py-3" id="mainNav">
            <div class="container px-4 px-lg-5">
                <a class="navbar-brand" href="#page-top">Home</a>
                <button class="navbar-toggler navbar-toggler-right" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ms-auto my-2 my-lg-0">
                        <li class="nav-item"><a class="nav-link" href="table.php">Powers</a></li>
                        <li class="nav-item"><a class="nav-link" href="ratecake.php">Upload Your Own Superhero!</a></li>
                    </ul>
                </div>
            </div>
        </nav>

        <!-- Masthead-->
        <header class="masthead">
            <div class="container px-4 px-lg-5 h-100">
                <div class="row gx-4 gx-lg-5 h-100 align-items-center justify-content-center text-center">
                    <div class="col-lg-8 align-self-end">
                        <h1 class="text-white font-weight-bold"> The Highs and Lows of Being a Superhero </h1>
                        <hr class="divider" />
                    </div>
                    <div class="col-lg-8 align-self-baseline">
                        <p class="text-white-75 mb-5">The Legion of Justice are a team of superheroes who use their powers to protect Metcalfe from danger. Through their adventures, our heroes will make allies, enemies and discoveries about their respective pasts and their powers. </p>
                        <a class="btn btn-primary btn-xl" href="#about">Meet the Team</a>
                    </div>
                </div>
            </div>
        </header>
        <!-- characters -->
        <section class="page-section" id="about">
            <div class="container px-4 px-lg-5">
                <h2 class="text-center mt-0">Characters</h2>
                <hr class="divider" />
                <div class="row gx-4 gx-lg-5">
                    <div class="row gx-4 gx-lg-5 h-100 align-items-center justify-content-center text-center">
                        <h5>After a strange bolt of green lightning strikes a group of people, they discover they have superhuman abilities use them for good. </h5>
                        
                        
                        <head><style>.xpdopen { display: none; }</style><style>div[jsaction*=lightbox] { display: none; }</style>
                        <style>
                        table {
                          font-family: arial, sans-serif;
                          border-collapse: collapse;
                          width: 100%;
                        }

                        td, th {
                          border: 1px solid #dddddd;
                          text-align: left;
                          padding: 8px;
                        }

                        tr:nth-child(even) {
                          background-color: #dddddd;
                        }
                        </style>

                        <table>
                          <tr>
                            <td><img src="assets/img/blueblur.jpg" alt="" width="600" height="450" class="center"></td>
                            <td><h5 class="text-muted mb-0">The sensitive, natural leader of the group, Rory Reed has the power of superspeed and takes his responsibilities seriously. As Blue Blur, he understands that he must protect his teammates as best he can. He cares deeply for those around him and considers his options before acting. </h5></td>

                          </tr>
                          <tr>
                            <td><img src="assets/img/hyperspeed.jpg" alt="" width="600" height="450" class="center"></td>
                            <td><h5 class="text-muted mb-0">The older brother of Blue Blur, Elijah Reed is more mature and abides more strictly to his instructions. He initially expressed mild reluctance about using his powers as a superhero but he quicky warmed to the idea. Hyperspeed is killed during the fight with the villain Jade Skull, but is later resurrected by the Ethereal Animos with Tephrakinesis instead of his superspeed and becomes the thief Ashcloud. In the end, Elijah enters self-exile as his actions catch up with him. </h5></td>
                          </tr>
                          <tr>
                            <td><div class="mb-2"><img src="assets/img/redlegend.jpg" alt="" width="600" height="450" class="center"></td>
                            <td><h5 class="text-muted mb-0">The warrior of the group with the most tragic story of the lot, Amos Northern lost his wife in a car accident before discovering his powers: pyrokinesis. due to this meaning the only family he has left is his daughter Rosie, Amos becomes more protective of her than before and struggles to let her be more independent. </h5></td>
                          </tr>
                          <tr>
                            <td><img src="assets/img/constellation.jpg" alt="" width="600" height="450" class="center"></td>
                            <td><h5 class="text-muted mb-0">The team medic, James Fox completed medical school and became a nurse. After developing Astrokinesis, allowing him to create entities made of stars, he joined the Legion of Justice and became the superhero Constellation. He is kind, caring and knowledgeable with a passive attitude, being one of few heroes who will only fight if he has to. </h5></td>
                          </tr>
                          <tr>
                            <td><img src="assets/img/spectralarrow.jpg" alt="" width="600" height="450" class="center"></td>
                            <td><h5 class="text-muted mb-0">Comfortable and proud of who he is, Luke Harroway works as an archery instructor and is incredibly skilled and consistent. Lukes powers allow him to manipulate luck itself, meaning his arrows are superhumanly accurate. Being on the Autistic Spectrum like Autism Man, Luke was always logical, fair and bright, but was picked on by his classmates. Spectral Arrow has embraced his neurodivergence, calling it his other "superpower"</h5></td>
                          </tr>
                          <tr>
                            <td><img src="assets/img/kunoiche.jpg" alt="" width="600" height="450" class="center"></td>
                            <td><h5 class="text-muted mb-0">A brave warrior like her partner, Isabelle Beard is a superhuman with the power to control paint. However, she prefers to use her physical fighting skills as the superhero Kunoiche. Having built her outfit herself from clothing and materials in her own home, Kunoiche's outfit is quite different to those of the Legion of Justice. </h5></td>
                          </tr>
                          <tr>
                            <td><img src="assets/img/autismman.jpg" alt="" width="600" height="450" class="center"></td>
                            <td><h5 class="text-muted mb-0">The Wealthy benefactor of the Legion of Justice, Nicholas Beard claimed to already have "superpowers" by being on the autistic spectrum like Luke and has an affinity for water, Autism Man's main ability is hydrokinesis, allowing him to generate and project bursts of water. Another aspect of his powers and Autism, Nicholas can release an explosion of water when he experiences sensory overload. Nicholas is extremely logical, fair, optimistic and a talented inventor, responsible for creating a prototype hydroelectric vehicle engine and the Legion's ship, <i>The Hyacinth</i>. </h5></td>
                          </tr>
                          <tr>
                            <td><img src="assets/img/greenbreach.jpg" alt="" width="600" height="450" class="center"></td>
                            <td><h5 class="text-muted mb-0">Rosie Northern is the youngest member of the Legion of Justice and is the independent, brave daughter of Amos. She dislikes how tight of a leash Amos holds on her, but she understands why: losing her mother took a toll on him. With Amos working as a firefighter prior to her mothers death, Her father still inspires her decision to join him in the legion and use her Portal powers as the superhero Greenbreach. A few years after the Legion disbanding, Rosie returns to a dangerous, dishevelled Metcalfe with her superhuman husband and a new team of heroes. </h5></td>
                        </tr>
                        </table>
                    </div>
                </div>
            </div>
        </section>
        <!-- Call to action-->
        <section class="page-section bg-dark text-white">
            <div class="container px-4 px-lg-5 text-center">
                <h2 class="mb-4">Return to the login page</h2>
                <a class="btn btn-light btn-xl" href="index.php">Log Out</a>

            </div>
        </section>
        <!-- Footer-->
        <footer class="bg-light py-5">
            <div class="container px-4 px-lg-5"><div class="small text-center text-muted">Copyright &copy; The Highs and Lows of Being a Superhero 2023</div></div>
        </footer>
    </body>
</html>
